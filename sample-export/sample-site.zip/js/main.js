/* SiteBuilder Vanilla Client Runtime — no editor dependencies required. */
(function () {
  'use strict';

  function ready(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  function setupMobileNavigation() {
    var toggles = document.querySelectorAll('.sb-nav-toggle');
    Array.prototype.forEach.call(toggles, function (toggle) {
      toggle.addEventListener('click', function () {
        var header = toggle.closest('header');
        if (!header) return;
        var menu = header.querySelector('.sb-nav-menu');
        if (!menu) return;
        var isOpen = menu.classList.toggle('open');
        toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      });
    });
  }

  function setupAuth() {
    var forms = document.querySelectorAll('.sb-firebase-auth-form');
    if (!forms.length) return;

    var fbConfig = null;
    var auth = null;
    var initError = null;

    if (fbConfig && typeof firebase !== 'undefined') {
      try {
        if (!firebase.apps.length) {
          firebase.initializeApp(fbConfig);
        }
        auth = firebase.auth();
      } catch (error) {
        initError = error;
      }
    }

    Array.prototype.forEach.call(forms, function (form) {
      var configured = form.getAttribute('data-auth-configured') === 'true' && Boolean(auth);
      var redirectUrl = form.getAttribute('data-auth-redirect') || '';
      var mode = form.getAttribute('data-auth-mode') || 'both';
      var isSignUp = mode === 'signup';

      var submitBtn = form.querySelector('.sb-firebase-submit-btn');
      var toggleBtn = form.querySelector('.sb-auth-mode-toggle');
      var toggleLabel = form.querySelector('.sb-auth-toggle-label');
      var emailInput = form.querySelector('.sb-auth-email');
      var passInput = form.querySelector('.sb-auth-password');
      var msgBox = form.querySelector('.sb-auth-msg');
      var googleBtn = form.querySelector('.sb-firebase-google-btn');

      function showMessage(message, kind) {
        if (!msgBox) return;
        msgBox.textContent = message;
        msgBox.className = 'sb-auth-msg visible ' + (kind || 'info');
      }

      function goToRedirect() {
        if (!redirectUrl || redirectUrl === '#' || redirectUrl === '/') return;
        window.location.href = redirectUrl;
      }

      if (!configured) {
        showMessage(
          initError
            ? 'Authentication is unavailable: ' + initError.message
            : 'Authentication is not configured for this website yet. Add your Firebase keys in SiteBuilder settings.',
          'info'
        );
        if (submitBtn) submitBtn.disabled = true;
        if (googleBtn) googleBtn.disabled = true;
        return;
      }

      // Already signed in? Send the visitor to the configured redirect target.
      auth.onAuthStateChanged(function (user) {
        if (user) {
          showMessage('Signed in as ' + (user.email || 'user') + '.', 'success');
          goToRedirect();
        }
      });

      if (toggleBtn) {
        toggleBtn.addEventListener('click', function () {
          isSignUp = !isSignUp;
          if (submitBtn) submitBtn.textContent = isSignUp ? 'Create Account' : 'Sign In';
          if (toggleLabel) toggleLabel.textContent = isSignUp ? 'Already have an account?' : "Don't have an account?";
          toggleBtn.textContent = isSignUp ? 'Sign In' : 'Sign Up';
          if (passInput) passInput.setAttribute('autocomplete', isSignUp ? 'new-password' : 'current-password');
          if (msgBox) msgBox.className = 'sb-auth-msg';
        });
      }

      form.addEventListener('submit', function (event) {
        event.preventDefault();
        var email = emailInput ? emailInput.value.trim() : '';
        var password = passInput ? passInput.value : '';
        if (!email || !password) {
          showMessage('Please fill in both your email and password.', 'error');
          return;
        }

        if (submitBtn) submitBtn.disabled = true;
        var action = isSignUp
          ? auth.createUserWithEmailAndPassword(email, password)
          : auth.signInWithEmailAndPassword(email, password);

        action.then(function () {
          showMessage(isSignUp ? 'Account created successfully!' : 'Signed in successfully!', 'success');
          goToRedirect();
        }).catch(function (error) {
          showMessage(error && error.message ? error.message : 'Authentication failed', 'error');
        }).then(function () {
          if (submitBtn) submitBtn.disabled = false;
        });
      });

      if (googleBtn) {
        googleBtn.addEventListener('click', function () {
          var provider = new firebase.auth.GoogleAuthProvider();
          auth.signInWithPopup(provider).then(function () {
            showMessage('Signed in with Google!', 'success');
            goToRedirect();
          }).catch(function (error) {
            showMessage(error && error.message ? error.message : 'Google Sign-In failed', 'error');
          });
        });
      }
    });
  }

  ready(function () {
    setupMobileNavigation();
    setupAuth();
  });
})();
