/* SiteBuilder Vanilla Client Runtime — no editor dependencies required. */
(function () {
  'use strict';

  function ready(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn);
    } else {
      fn();
    }
  }

  function setupMobileNavigation() {
    var toggles = document.querySelectorAll('.sb-nav-toggle');
    Array.prototype.forEach.call(toggles, function (toggle) {
      toggle.addEventListener('click', function () {
        var header = toggle.closest('header');
        if (!header) return;
        var menu = header.querySelector('.sb-nav-menu');
        if (!menu) return;
        var isOpen = menu.classList.toggle('open');
        toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      });
    });
  }

  function setupAuth() {
    var forms = document.querySelectorAll('.sb-firebase-auth-form');
    var fbConfig = null;
    var auth = null;
    var initError = null;

    if (fbConfig && typeof firebase !== 'undefined') {
      try {
        if (!firebase.apps.length) {
          firebase.initializeApp(fbConfig);
        }
        if (typeof firebase.analytics === 'function' && fbConfig.measurementId) {
          try { firebase.analytics(); } catch (e) { /* analytics init */ }
        }
        if (typeof firebase.auth === 'function') {
          auth = firebase.auth();
          if (firebase.auth.Auth && firebase.auth.Auth.Persistence) {
            var persistMode = 'LOCAL';
            var pType = firebase.auth.Auth.Persistence[persistMode] || firebase.auth.Auth.Persistence.LOCAL;
            auth.setPersistence(pType).catch(function () {});
          }
        }
      } catch (error) {
        initError = error;
      }
    }

    if (!forms.length) return;

    // Maps Firebase error codes to plain-language messages.
    function friendlyAuthError(error) {
      var code = (error && error.code) || '';
      var messages = {
        'auth/invalid-email': 'That email address looks invalid.',
        'auth/missing-password': 'Please enter your password.',
        'auth/user-disabled': 'This account has been disabled.',
        'auth/user-not-found': 'No account was found with that email address.',
        'auth/wrong-password': 'Incorrect password. Please try again.',
        'auth/invalid-credential': 'Incorrect email or password.',
        'auth/invalid-login-credentials': 'Incorrect email or password.',
        'auth/email-already-in-use': 'An account with this email already exists. Try signing in instead.',
        'auth/weak-password': 'Please choose a stronger password (at least 6 characters).',
        'auth/too-many-requests': 'Too many attempts. Please wait a moment and try again.',
        'auth/network-request-failed': 'Network error - check your connection and try again.',
        'auth/operation-not-allowed': 'This sign-in method is not enabled for this website yet.',
        'auth/unauthorized-domain': 'This website domain is not authorized in the Firebase console.',
        'auth/popup-blocked': 'Your browser blocked the sign-in popup. Redirecting instead...',
        'auth/popup-closed-by-user': 'The sign-in window was closed before finishing.',
        'auth/cancelled-popup-request': 'Another sign-in attempt is already in progress.',
        'auth/account-exists-with-different-credential': 'An account already exists for this email with a different sign-in method.',
        'auth/missing-email': 'Please enter your email address.'
      };
      if (messages[code]) return messages[code];
      return (error && error.message) || 'Authentication failed. Please try again.';
    }

    Array.prototype.forEach.call(forms, function (form) {
      var configured = form.getAttribute('data-auth-configured') === 'true' && Boolean(auth);
      var redirectUrl = form.getAttribute('data-auth-redirect') || '';
      var mode = form.getAttribute('data-auth-mode') || 'both';
      var isSignUp = mode === 'signup';

      var submitBtn = form.querySelector('.sb-firebase-submit-btn');
      var toggleBtn = form.querySelector('.sb-auth-mode-toggle');
      var toggleLabel = form.querySelector('.sb-auth-toggle-label');
      var emailInput = form.querySelector('.sb-auth-email');
      var passInput = form.querySelector('.sb-auth-password');
      var msgBox = form.querySelector('.sb-auth-msg');
      var googleBtn = form.querySelector('.sb-firebase-google-btn');

      function showMessage(message, kind) {
        if (!msgBox) return;
        msgBox.textContent = message;
        msgBox.className = 'sb-auth-msg visible ' + (kind || 'info');
      }

      function goToRedirect() {
        if (!redirectUrl || redirectUrl === '#' || redirectUrl === '/') return;
        window.location.href = redirectUrl;
      }

      if (!configured) {
        showMessage(
          initError
            ? 'Authentication is unavailable: ' + initError.message
            : 'Authentication is not configured for this website yet. Add your Firebase keys in SiteBuilder settings.',
          'info'
        );
        if (submitBtn) submitBtn.disabled = true;
        if (googleBtn) googleBtn.disabled = true;
        return;
      }

      // Already signed in? Send the visitor to the configured redirect target.
      auth.onAuthStateChanged(function (user) {
        if (user) {
          showMessage('Signed in as ' + (user.email || 'user') + '.', 'success');
          goToRedirect();
        }
      });

      if (toggleBtn) {
        toggleBtn.addEventListener('click', function () {
          isSignUp = !isSignUp;
          if (submitBtn) submitBtn.textContent = isSignUp ? 'Create Account' : 'Sign In';
          if (toggleLabel) toggleLabel.textContent = isSignUp ? 'Already have an account?' : "Don't have an account?";
          toggleBtn.textContent = isSignUp ? 'Sign In' : 'Sign Up';
          if (passInput) passInput.setAttribute('autocomplete', isSignUp ? 'new-password' : 'current-password');
          if (msgBox) msgBox.className = 'sb-auth-msg';
        });
      }

      form.addEventListener('submit', function (event) {
        event.preventDefault();
        var email = emailInput ? emailInput.value.trim() : '';
        var password = passInput ? passInput.value : '';
        if (!email || !password) {
          showMessage('Please fill in both your email and password.', 'error');
          return;
        }
        if (submitBtn && submitBtn.disabled) return;

        if (submitBtn) submitBtn.disabled = true;
        var action = isSignUp
          ? auth.createUserWithEmailAndPassword(email, password)
          : auth.signInWithEmailAndPassword(email, password);

        action.then(function () {
          showMessage(isSignUp ? 'Account created successfully!' : 'Signed in successfully!', 'success');
          goToRedirect();
        }).catch(function (error) {
          showMessage(friendlyAuthError(error), 'error');
        }).then(function () {
          if (submitBtn) submitBtn.disabled = false;
        });
      });

      if (googleBtn) {
        googleBtn.addEventListener('click', function () {
          if (googleBtn.disabled) return;
          googleBtn.disabled = true;
          var provider = new firebase.auth.GoogleAuthProvider();

          function finish() {
            googleBtn.disabled = false;
          }

          auth.signInWithPopup(provider).then(function () {
            showMessage('Signed in with Google!', 'success');
            goToRedirect();
            finish();
          }).catch(function (error) {
            var code = (error && error.code) || '';
            // Popups blocked (common on mobile browsers) — fall back to the
            // redirect flow so the visitor can still sign in.
            if (code === 'auth/popup-blocked' || code === 'auth/popup-closed-by-user' || code === 'auth/web-storage-unsupported') {
              showMessage(friendlyAuthError(error), 'info');
              return auth.signInWithRedirect(provider).catch(function (redirectError) {
                showMessage(friendlyAuthError(redirectError), 'error');
                finish();
              });
            }
            showMessage(friendlyAuthError(error), 'error');
            finish();
          });
        });
      }
    });
  }

  ready(function () {
    setupMobileNavigation();
    setupAuth();
  });
})();
